from cx_Freeze import setup, Executable

include_files = ['resources/']

setup(
    name="Microgrid editor",
    version="1.0",
    description="Allows creation and edition of microgrids",
    options={'build_exe': {'include_files': include_files}},
    executables=[Executable("microgrid_editor.py", icon='resources/thunder.ico')],
)
