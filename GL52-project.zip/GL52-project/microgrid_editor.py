#!/usr/bin/env python
import json
from os.path import isfile

import wx

from pkg.canvas.my_canvas import MyCanvas, Modes
from pkg.components.bus import Bus
from pkg.components.charge import Charge
from pkg.components.source import Source
from pkg.components.storage import Storage
from pkg.links.branch import Branch
from pkg.links.line import Line
from pkg.microgrid_parser.microgrid_parser import MicroGridParser
from pkg.settings.file_settings import FILE_DATA, OBJECT_NAMES


class DrawFrame(wx.Frame):
    FRAME_TITLE = 'Microgrid editor'

    def __init__(self, *args, **kwargs):
        wx.Frame.__init__(self, *args, **kwargs)
        wx.Dialog.EnableLayoutAdaptation(True)

        self.Centre()

        self.CreateStatusBar()
        self.add_canvas()
        self.create_menu_bar()

        self.SetTitle(self.FRAME_TITLE)
        self.SetIcon(wx.Icon("resources/thunder.png"))

        self.Show(True)

    def create_menu_bar(self):

        menubar = wx.MenuBar()
        file_menu = wx.Menu()
        components_menu = wx.Menu()
        bus_menu = wx.Menu()
        links_menu = wx.Menu()

        new_item = file_menu.Append(wx.NewId(), '&New\tCtrl+N', 'Create a new file')
        open_item = file_menu.Append(wx.NewId(), '&Open\tCtrl+O', 'Open an existing file')
        save_item = file_menu.Append(wx.NewId(), '&Save\tCtrl+S', 'Save the changes to current file')
        save_as_item = file_menu.Append(wx.NewId(), 'S&ave as\tCtrl+Shift+S', 'Save the changes to given file')
        file_menu.AppendSeparator()
        quit_item = file_menu.Append(wx.ID_EXIT, '&Quit\tCtrl+Q', 'Quit application')

        add_source_item = components_menu.Append(wx.NewId(), 'Add &source\tCtrl+G', 'Add a source')
        add_charge_item = components_menu.Append(wx.NewId(), 'Add &charge\tCtrl+A', 'Add a charge')
        add_storage_item = components_menu.Append(wx.NewId(), 'Add s&torage\tCtrl+T', 'Add a storage')

        add_bus_item = bus_menu.Append(wx.NewId(), 'Add &bus\tCtrl+B', 'Add a bus')

        add_line_item = links_menu.Append(wx.NewId(), 'Add &line\tCtrl+L', 'Connect two bus')
        add_branch_item = links_menu.Append(wx.NewId(), 'Add &branch\tCtrl+R', 'Connect a component to a bus')

        menubar.Append(file_menu, '&File')
        menubar.Append(bus_menu, '&Bus')
        menubar.Append(components_menu, '&Components')
        menubar.Append(links_menu, '&Links')
        self.SetMenuBar(menubar)

        self.Bind(wx.EVT_MENU, self.on_new, new_item)
        self.Bind(wx.EVT_MENU, self.on_open, open_item)
        self.Bind(wx.EVT_MENU, self.on_save, save_item)
        self.Bind(wx.EVT_MENU, self.on_save_as, save_as_item)
        self.Bind(wx.EVT_MENU, self.on_quit, quit_item)

        self.Bind(wx.EVT_CLOSE, self.on_quit)

        self.Bind(wx.EVT_MENU, lambda mode: self.my_canvas.SetMode(Modes.BUS), add_bus_item)
        self.Bind(wx.EVT_MENU, lambda mode: self.my_canvas.SetMode(Modes.SOURCE), add_source_item)
        self.Bind(wx.EVT_MENU, lambda mode: self.my_canvas.SetMode(Modes.CHARGE), add_charge_item)
        self.Bind(wx.EVT_MENU, lambda mode: self.my_canvas.SetMode(Modes.STORAGE), add_storage_item)
        self.Bind(wx.EVT_MENU, lambda mode: self.my_canvas.SetMode(Modes.LINE), add_line_item)
        self.Bind(wx.EVT_MENU, lambda mode: self.my_canvas.SetMode(Modes.BRANCH), add_branch_item)

    def add_canvas(self):

        self.my_canvas = MyCanvas(self, -1, (700, 500), ProjectionFun=None, Debug=0)

        self.Show(True)

        self.current_path = ''
        self.mode = Mode.INVALID_MODE

        self.reset_canvas()

    def reset_canvas(self):
        self.set_saved_state(True)
        self.my_canvas.reset()

    def is_saved(self):
        return self.saved

    def set_saved_state(self, boolean):
        self.saved = boolean
        self.set_current_path()

    def set_current_path(self, path=None):

        frame_title = self.FRAME_TITLE

        if path is not None: self.current_path = path
        if self.current_path != '' or not self.is_saved(): frame_title += ' - '
        if not self.is_saved(): frame_title += "*"
        frame_title += self.current_path

        self.SetTitle(frame_title)

    def on_new(self, event):

        new_file = False

        if not self.is_saved():
            if self.not_saved_warning() == wx.NO:
                return
            new_file = True

        if self.is_saved() or new_file:
            self.reset_canvas()
            self.set_saved_state(True)
            self.set_current_path('')

    def on_quit(self, event):
        if not self.is_saved():
            if self.not_saved_warning() == wx.NO:
                return

        self.Destroy()

    def on_open(self, event):
        open_file = False
        if not self.is_saved():
            if self.not_saved_warning() == wx.NO:
                return
            open_file = True

        if self.is_saved() or open_file:

            open_file_dialog = self.open_file_dialog()

            if open_file_dialog.ShowModal() == wx.ID_CANCEL:
                return

            path = open_file_dialog.GetPath()
            file_type = open_file_dialog.GetFilterIndex()

            if file_type == Mode.FORMATTED_MODE:
                self.open_formatted(path)
            elif file_type == Mode.JSON_MODE:
                self.open_json(path)

    def on_save(self, event):
        if self.current_path != '':
            if self.mode == Mode.FORMATTED_MODE:
                self.save_formatted(self.current_path)
            elif self.mode == Mode.JSON_MODE:
                self.save_json(self.current_path)
            else:
                raise Exception("Invalid mode (must be TXT : 0, or JSON : 1 => " + str(self.mode))
        else:
            self.on_save_as(None)

    def on_save_as(self, event):

        save_file_dialog = self.save_file_dialog()

        if save_file_dialog.ShowModal() == wx.ID_CANCEL:
            return

        path = save_file_dialog.GetPath()
        file_type = save_file_dialog.GetFilterIndex()

        if file_type == Mode.FORMATTED_MODE:
            self.save_formatted(path)
        elif file_type == Mode.JSON_MODE:
            self.save_json(path)

    def open_formatted(self, path):
        parser = MicroGridParser()
        parser.parse_file(path)
        instantiation_order = [
            {'key': Bus.key, 'callback': self.my_canvas.add_bus_from_formatted},
            {'key': Line.key, 'callback': self.my_canvas.add_line_from_formatted}
        ]

        self.reset_canvas()

        for category in instantiation_order:
            print("Instantiating " + category['key'] + "\n")
            temporary_path = FILE_DATA.get(category['key'], {}).get('temporary_output_file')
            if isfile(temporary_path):
                with open(temporary_path) as f:
                    f.readline()  # Skips the first line as it is the section start card
                    for characteristics in f:
                        category['callback'](characteristics)

        self.my_canvas.Canvas.ZoomToBB()
        self.set_current_path(path)
        self.set_saved_state(True)
        self.mode = Mode.FORMATTED_MODE

        parser.remove_temporary_files()

    def open_json(self, path):
        self.reset_canvas()

        with open(path, 'r') as f:
            objects_json = json.load(f)

            instantiation_order = [
                {'key': Bus.key, 'callback': self.my_canvas.add_bus_from_json},
                {'key': Source.key, 'callback': self.my_canvas.add_source_from_json},
                {'key': Storage.key, 'callback': self.my_canvas.add_storage_from_json},
                {'key': Charge.key, 'callback': self.my_canvas.add_charge_from_json},
                {'key': Line.key, 'callback': self.my_canvas.add_line_from_json},
                {'key': Branch.key, 'callback': self.my_canvas.add_branch_from_json}
            ]

            for category in instantiation_order:
                print("Instantiating " + category['key'] + "\n")
                objects = objects_json.get(category['key'], [])
                for object_dict in objects:
                    category['callback'](object_dict)

        self.my_canvas.Canvas.ZoomToBB()
        self.set_current_path(path)
        self.set_saved_state(True)
        self.mode = Mode.JSON_MODE

    def save_formatted(self, path):
        with open(path, 'w') as f:
            objects = self.my_canvas.components

            for category in OBJECT_NAMES.values():

                category_start_string = FILE_DATA.get(category, {}).get('start')
                category_end_string = FILE_DATA.get(category, {}).get('end')
                objects_from_category = objects.get(category)

                if category_start_string is not None and category_end_string is not None and objects_from_category is not None:
                    f.write(category_start_string + '\n')

                    for id, object in sorted(objects_from_category.items()):
                        f.write(str(object) + '\n')

                    f.write(category_end_string + '\n')

            self.set_current_path(path)
            self.set_saved_state(True)
            self.mode = Mode.FORMATTED_MODE

    def save_json(self, path):
        objects_json = {}

        with open(path, 'w') as f:
            objects = self.my_canvas.components

            for category in OBJECT_NAMES.values():

                objects_json[category] = []
                objects_from_category = objects.get(category)

                for id, object in objects_from_category.items():
                    objects_json[category].append(object.get_json_characteristics())

            json.dump(objects_json, f)

            self.set_current_path(path)
            self.set_saved_state(True)
            self.mode = Mode.JSON_MODE

    def not_saved_warning(self):
        return wx.MessageBox("Current content has not been saved. Do you want to continue ?", "Please confirm",
                             wx.ICON_QUESTION | wx.YES_NO, self)

    def save_file_dialog(self):
        title = "Save to text or json file"
        wildcard = "Text files (*.txt)|*.txt|Json files (*.json)|*.json"

        return wx.FileDialog(self, title, "", "", wildcard, wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT)

    def open_file_dialog(self):
        title = "Save to text or json file"
        wildcard = "Text files (*.txt)|*.txt|Json files (*.json)|*.json"
        return wx.FileDialog(self, title, "", "", wildcard, wx.FD_OPEN | wx.FD_FILE_MUST_EXIST)


class Mode:
    (
        INVALID_MODE,
        FORMATTED_MODE,
        JSON_MODE
    ) = range(-1, 2, 1)


app = wx.App(0)

DrawFrame(None,
          title="FloatCanvas Moving Object App",
          size=(700, 500),
          )
app.MainLoop()
