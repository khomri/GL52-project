OBJECT_NAMES = {
    'BUS_NAME': 'bus',
    'LINE_NAME': 'line',
    'SOURCE_NAME': 'source',
    'CHARGE_NAME': 'charge',
    'BRANCH_NAME': 'branch',
    'STORAGE_NAME': 'storage',
}

FILE_DATA = {
    OBJECT_NAMES.get('BUS_NAME', 'bus'): {
        'start': 'BUS DATA FOLLOWS',
        'end': '-999',
        'temporary_output_file': 'bus_temporary_data.txt',
    },
    OBJECT_NAMES.get('LINE_NAME', 'links'): {
        'start': 'BRANCH DATA FOLLOWS',
        'end': '-999',
        'temporary_output_file': 'lines_temporary_data.txt',
    }
}
