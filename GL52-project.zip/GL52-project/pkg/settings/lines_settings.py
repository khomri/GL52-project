from file_settings import OBJECT_NAMES

LINES_DATA = {
    OBJECT_NAMES.get('BUS_NAME', 'bus'): [
        {
            'start_column': 1,
            'end_column': 4,
            'title': 'Bus number (I)',
            'attribute_name': 'id',
            'attribute_type': 'int',
        },
        # Mistake producing incoherent data and IndexError exceptions
        # {
        #     'start_column': 7,
        #     'end_column': 17,
        #     'title': 'Name (A)',
        #     'attribute_name': 'name'
        # },
        {
            'start_column': 6,
            'end_column': 17,
            'title': 'Name (A)',
            'attribute_name': 'name',
            'attribute_category': 'text',
            'attribute_type': 'str'
        },
        {
            'start_column': 19,
            'end_column': 20,
            'title': 'Load flow area number (I)',
            'attribute_name': 'load_flow',
            'attribute_category': 'number',
            'attribute_type': 'int'
        },
        {
            'start_column': 21,
            'end_column': 23,
            'title': 'Loss zone number (I)',
            'attribute_name': 'loss',
            'attribute_category': 'number',
            'attribute_type': 'int'
        },
        {
            'start_column': 25,
            'end_column': 26,
            'title': 'Type (I)',
            'attribute_name': 'type',
            'attribute_type': 'int',
            'attribute_category': 'choice',
            'attribute_options': {
                'choices': [
                    'Unregulated (load, PQ)',
                    'Hold MVAR generation within voltage limits (PQ)',
                    'Hold voltage within VAR limits (gen, PV)',
                    'Hold voltage and angle (swing, V - Theta)'
                ]
            }
        },
        {
            'start_column': 28,
            'end_column': 33,
            'title': 'Final voltage, p.u. (F)',
            'attribute_name': 'voltage',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 34,
            'end_column': 40,
            'title': 'Final angle, degrees (F)',
            'attribute_name': 'angle',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 41,
            'end_column': 49,
            'title': 'Load MW (F)',
            'attribute_name': 'load_mw',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 50,
            'end_column': 59,
            'title': 'Load MVAR (F)',
            'attribute_name': 'load_mvar',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 60,
            'end_column': 67,
            'title': 'Generation MW (F)',
            'attribute_name': 'generation_mw',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 68,
            'end_column': 75,
            'title': 'Generation MVAR (F)',
            'attribute_name': 'generation_mvar',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 77,
            'end_column': 83,
            'title': 'Base KV (F)',
            'attribute_name': 'base',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 85,
            'end_column': 90,
            'title': 'Desired volts (pu) (F)',
            'attribute_name': 'desired_volts',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 91,
            'end_column': 98,
            'title': 'Maximum MVAR or voltage limit (F)',
            'attribute_name': 'max_voltage',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 99,
            'end_column': 106,
            'title': 'Minimum MVAR or voltage limit (F)',
            'attribute_name': 'min_voltage',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 107,
            'end_column': 114,
            'title': 'Shunt conductance G (per unit) (F)',
            'attribute_name': 'shunt_conductance',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 115,
            'end_column': 122,
            'title': 'Shunt susceptance B (per unit) (F)',
            'attribute_name': 'shunt_susceptance',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 124,
            'end_column': 127,
            'title': 'Remote controlled bus number (I)',
            'attribute_name': 'remote_number',
            'attribute_category': 'number',
            'attribute_type': 'int'
        }],
    OBJECT_NAMES.get('LINE_NAME', 'links'): [
        {
            'start_column': 1,
            'end_column': 4,
            'title': 'Tap bus number (I)',
            'attribute_name': 'from_object_id',
            'attribute_type': 'int'
        },
        {
            'start_column': 6,
            'end_column': 9,
            'title': 'Z bus number (I)',
            'attribute_name': 'to_object_id',
            'attribute_type': 'int'
        },
        {
            'start_column': 11,
            'end_column': 12,
            'title': 'Load flow area (I)',
            'attribute_name': 'load_flow',
            'attribute_category': 'number',
            'attribute_type': 'int'
        },
        # Mistake producing incoherent data and IndexError exceptions
        # {
        #     'start_column': 13,
        #     'end_column': 14,
        #     'title': 'Loss zone (I)',
        #     'attribute_name': 'loss',
        #     'attribute_type': 'int'
        # },
        {
            'start_column': 13,
            'end_column': 15,
            'title': 'Loss zone (I)',
            'attribute_name': 'loss',
            'attribute_category': 'number',
            'attribute_type': 'int'
        },
        {
            'start_column': 17,
            'end_column': 17,
            'title': 'Circuit (I)',
            'attribute_name': 'circuit',
            'attribute_category': 'number',
            'attribute_type': 'int'
        },
        {
            'start_column': 19,
            'end_column': 19,
            'title': 'Type (I)',
            'attribute_name': 'type',
            'attribute_category': 'number',
            'attribute_type': 'int',
            'attribute_category': 'choice',
            'attribute_options': {
                'choices': [
                    'Transmission line',
                    'Fixed tap',
                    'Variable tap for voltage control (TCUL, LTC)',
                    'Variable tap (turns ratio) for MVAR control',
                    'Variable phase angle for MW control (phase shifter)'
                ]
            }
        },
        {
            'start_column': 20,
            'end_column': 29,
            'title': 'Branch resistance R, per unit (F)',
            'attribute_name': 'branch_resistance',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 30,
            'end_column': 40,
            'title': 'Branch reactance X, per unit (F)',
            'attribute_name': 'branch_reactance',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 41,
            'end_column': 50,
            'title': 'Line charging B, per unit (F)',
            'attribute_name': 'line_charging',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 51,
            'end_column': 55,
            'title': 'Line MVA rating No 1 (I)',
            'attribute_name': 'line_rating_1',
            'attribute_category': 'number',
            'attribute_type': 'int'
        },
        {
            'start_column': 57,
            'end_column': 61,
            'title': 'Line MVA rating No 2 (I)',
            'attribute_name': 'line_rating_2',
            'attribute_category': 'number',
            'attribute_type': 'int'
        },
        {
            'start_column': 63,
            'end_column': 67,
            'title': 'Line MVA rating No 3 (I)',
            'attribute_name': 'line_rating_3',
            'attribute_category': 'number',
            'attribute_type': 'int'
        },
        {
            'start_column': 69,
            'end_column': 72,
            'title': 'Control bus number',
            'attribute_name': 'control_bus_number',
            'attribute_category': 'number',
            'attribute_type': 'int'
        },
        {
            'start_column': 74,
            'end_column': 74,
            'title': 'Side (I)',
            'attribute_name': 'side',
            'attribute_type': 'int',
            'attribute_category': 'choice',
            'attribute_options': {
                'choices': [
                    'Controlled bus is one of the terminals',
                    'Controlled bus is near the tap side',
                    'Controlled bus is near the impedance side (Z bus)'
                ]
            }
        },
        {
            'start_column': 77,
            'end_column': 82,
            'title': 'Transformer final turns ratio (F)',
            'attribute_name': 'transformer_turns_ratio',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 84,
            'end_column': 90,
            'title': 'Transformer (phase shifter) final angle (F)',
            'attribute_name': 'transformer_angle',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 91,
            'end_column': 97,
            'title': 'Minimum tap or phase shift (F)',
            'attribute_name': 'min_phase_shift',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 98,
            'end_column': 104,
            'title': 'Maximum tap or phase shift (F)',
            'attribute_name': 'max_phase_shift',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        {
            'start_column': 106,
            'end_column': 111,
            'title': 'Step size (F)',
            'attribute_name': 'step_size',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        # Mistake producing incoherent data and IndexError exceptions
        # {
        #     'start_column': 113,
        #     'end_column': 119,
        #     'title': 'Minimum voltage, MVAR or MW limit (F)',
        #     'attribute_name': 'min_voltage'
        # },
        {
            'start_column': 113,
            'end_column': 118,
            'title': 'Minimum voltage, MVAR or MW limit (F)',
            'attribute_name': 'min_voltage',
            'attribute_category': 'number',
            'attribute_type': 'float'
        },
        # Mistake producing incoherent data and IndexError exceptions
        # {
        #     'start_column': 120,
        #     'end_column': 126,
        #     'title': 'Maximum voltage, MVAR or MW limit (F)',
        #     'attribute_name': 'max_voltage'
        # },
        {
            'start_column': 119,
            'end_column': 121,
            'title': 'Maximum voltage, MVAR or MW limit (F)',
            'attribute_name': 'max_voltage',
            'attribute_category': 'number',
            'attribute_type': 'float'
        }]
}
