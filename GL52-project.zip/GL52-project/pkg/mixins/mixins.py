from pydoc import locate

from pkg.microgrid_parser.microgrid_parser import MicroGridParser
from pkg.settings import lines_settings
from pkg.settings.lines_settings import LINES_DATA


class CharacteristicsMixin:
    def get_formatted_characteristics(self):

        formatted_characteristics = ''
        number_of_characteristics = len(LINES_DATA.get(self.key, []))

        for n, characteristic in enumerate(LINES_DATA.get(self.key, [])):
            attribute_name = characteristic['attribute_name']
            start_column = characteristic['start_column']
            end_column = characteristic['end_column']
            required_len = end_column - start_column + 1

            value = str(self.__getattribute__(attribute_name))
            value_len = len(value)
            missing_spaces = required_len - value_len

            value = missing_spaces * ' ' + value

            if missing_spaces < 0:
                raise Exception(self.key + " " + str(
                    self.get_id()) + "'s Attribute '" + attribute_name + "'\'s value is too long to be exported : '" + value + "'\n")

            if n < number_of_characteristics - 1:
                next_characteristic = lines_settings.LINES_DATA[self.key][n + 1]
                spaces_between_attributes = next_characteristic['start_column'] - end_column - 1
                value += spaces_between_attributes * ' '

            formatted_characteristics += value

        return formatted_characteristics

    def set_characteristics_from_formatted(self, formatted_characteristics):

        for characteristic in LINES_DATA.get(self.key, []):
            attribute_name = characteristic['attribute_name']
            attribute_value = MicroGridParser.read_characteristic(characteristic, formatted_characteristics)
            self.__setattr__(attribute_name, attribute_value)

    def get_json_characteristics(self):

        json_characteristics = {}

        for characteristic in LINES_DATA.get(self.key, []):
            attribute_name = characteristic['attribute_name']
            attribute_value = self.__getattribute__(attribute_name)

            json_characteristics[attribute_name] = attribute_value

        if hasattr(self, 'XY'):
            position = self.XY
            if not isinstance(position, tuple):
                position = tuple(position)

            json_characteristics['XY'] = position

        return json_characteristics

    def set_characteristics_from_json(self, json_characteristics):

        # OLD VERSION : use the settings file
        # for characteristic in LINES_DATA.get(self.key, []):
        #     attribute_name = characteristic['attribute_name']
        #     attribute_type = locate(characteristic.get('attribute_type', 'unknown type'))
        #     attribute_value_str = json_characteristics.get(attribute_name)
        #     attribute_value = attribute_type(attribute_value_str)
        #
        #     self.__setattr__(attribute_name, attribute_value)
        #
        # if hasattr(self, 'XY') and json_characteristics.get('XY') is not None:
        #     point = json_characteristics['XY']
        #
        #     self.XY = point

        # NEW VERSION : use all the data in the json
        for characteristic_name, characteristic_value in json_characteristics.items():
            self.__setattr__(characteristic_name, characteristic_value)

    def set_characteristics(self, formatted_characteristics=None, json_characteristics=None):

        if formatted_characteristics is not None:
            self.set_characteristics_from_formatted(formatted_characteristics)
        elif json_characteristics is not None:
            self.set_characteristics_from_json(json_characteristics)
        else:
            self.set_default_characteristics()

    def set_default_characteristics(self):
        for characteristic in LINES_DATA.get(self.key, []):
            attribute_name = characteristic['attribute_name']
            attribute_type = locate(characteristic.get('attribute_type', 'unknown type'))

            if attribute_type is not None:
                attribute_value = attribute_type()
            else:
                attribute_value = ''

            self.__setattr__(attribute_name, attribute_value)

    def update_characteristic(self, attribute_name, attribute_value):
        self.__setattr__(attribute_name, attribute_value)
