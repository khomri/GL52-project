from wx import SpinCtrl, EVT_SPINCTRL

from mixins import UpdateObjectCharacteristicMixin


class MySpinCtrl(SpinCtrl, UpdateObjectCharacteristicMixin):
    def __init__(self, parent, object, attribute_name, *args, **kwargs):
        super(MySpinCtrl, self).__init__(parent, max=100000000, *args, **kwargs)

        self.object = object
        self.attribute_name = attribute_name
        self.max_length = self.get_max_length(attribute_name)

    def bind_change_event(self, method):
        self.Bind(EVT_SPINCTRL, method)
