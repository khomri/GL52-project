import wx

from pkg.dialogs.mixins import UpdateObjectCharacteristicMixin


class MyRadioBox(wx.RadioBox, UpdateObjectCharacteristicMixin):
    def __init__(self, object, attribute_name, *args, **kwargs):
        super(MyRadioBox, self).__init__(*args, **kwargs)

        self.object = object
        self.attribute_name = attribute_name
        self.max_length = self.get_max_length(attribute_name)

    def update_object_characteristic(self):
        value = self.GetSelection()
        self.object.__setattr__(self.attribute_name, value)
