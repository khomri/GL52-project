import wx

from my_radiobox import MyRadioBox
from my_spinctrl import MySpinCtrl
from my_spinctrldouble import MySpinCtrlDouble
from my_textctrl import MyTextCtrl
from pkg.components.bus import Bus
from pkg.links.line import Line
from pkg.settings.lines_settings import LINES_DATA


class MyAskDialog(wx.Dialog):
    def __init__(self, object, set_saved_state, *args, **kwargs):
        super(MyAskDialog, self).__init__(None, *args, **kwargs)

        self.SetTitle("Details")

        self.set_saved_state = set_saved_state

        main_sizer = wx.BoxSizer(wx.VERTICAL)

        data = LINES_DATA[object.key]

        for characteristic in data:
            element = self.get_element(object, characteristic)
            if element is not None:
                main_sizer.Add(element, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 10)

        btn = wx.Button(self, label="Close")
        btn.Bind(wx.EVT_BUTTON, self.OnClose)
        main_sizer.Add(btn, 0, wx.ALL | wx.CENTER, 10)
        main_sizer.SetSizeHints(self)

        self.SetSizer(main_sizer)
        self.Center()

    def OnClose(self, e):

        self.Destroy()

    def get_element(self, object, characteristic):

        element = None

        attribute_category = characteristic.get('attribute_category')
        attribute_type = characteristic.get('attribute_type')

        if attribute_category == 'choice':
            element = self.get_choice_element(object, characteristic)
        elif attribute_category == 'number':
            if attribute_type == 'int':
                element = self.get_int_element(object, characteristic)
            elif attribute_type == 'float':
                element = self.get_float_element(object, characteristic)
            else:
                element = self.get_default_element(object, characteristic)
        elif attribute_category == 'text':
            if attribute_type == 'str':
                element = self.get_str_element(object, characteristic)

        if element is None: element = self.get_default_element(object, characteristic)

        return element

    def get_default_element(self, object, characteristic):
        title = characteristic['title']
        attribute_name = characteristic['attribute_name']

        box = wx.BoxSizer(wx.HORIZONTAL)

        value = str(object.__getattribute__(attribute_name))

        title_text = wx.StaticText(self, label=title + " :")
        value_text = wx.StaticText(self, label=value, style=wx.ALIGN_CENTER)

        box.Add(title_text, 2, wx.EXPAND | wx.ALIGN_LEFT, 0)
        box.Add(value_text, 1, wx.EXPAND | wx.ALIGN_RIGHT, 0)

        return box

    def get_str_element(self, object, characteristic):
        title = characteristic['title']
        attribute_name = characteristic['attribute_name']

        box = wx.BoxSizer(wx.HORIZONTAL)

        value = object.__getattribute__(attribute_name)

        title_text = wx.StaticText(self, label=title + " :")
        text_ctrl = MyTextCtrl(self, object, attribute_name)

        text_ctrl.SetValue(value)

        box.Add(title_text, 2, wx.EXPAND | wx.ALIGN_LEFT, 0)
        box.Add(text_ctrl, 1, wx.EXPAND | wx.ALIGN_RIGHT, 0)

        text_ctrl.bind_change_event(self.on_change)

        return box

    def get_choice_element(self, object, characteristic):
        title = characteristic['title']
        attribute_name = characteristic['attribute_name']
        attribute_options = characteristic.get('attribute_options', {})
        choices = attribute_options.get('choices', [])

        selected_choice = object.__getattribute__(attribute_name)

        panel = wx.Panel(self)
        box = MyRadioBox(object, attribute_name, panel, label=title, choices=choices, style=wx.RA_SPECIFY_ROWS)
        box.SetSelection(selected_choice)
        box.Bind(wx.EVT_RADIOBOX, self.on_change)

        return panel

    def get_int_element(self, object, characteristic):

        return self.get_int_or_float_element(object, characteristic, 'int')

    def get_float_element(self, object, characteristic):

        return self.get_int_or_float_element(object, characteristic, 'float')

    def get_int_or_float_element(self, object, characteristic, type):
        title = characteristic['title']
        attribute_name = characteristic['attribute_name']
        attribute_options = characteristic.get('attribute_options', {})

        box = wx.BoxSizer(wx.HORIZONTAL)

        title_text = wx.StaticText(self, label=title + " :")

        parameters = {parameter_key: parameter_value for parameter_key, parameter_value in attribute_options.items()}
        value = object.__getattribute__(attribute_name)

        if type == 'int':
            spin = MySpinCtrl(self, object, attribute_name, **parameters)
        elif type == 'float':
            spin = MySpinCtrlDouble(self, object, attribute_name, **parameters)
        else:
            raise Exception('Unknown spin control type : ' + type)

        spin.SetValue(value)

        box.Add(title_text, 2, wx.EXPAND | wx.ALIGN_LEFT, 0)
        box.Add(spin, 1, wx.EXPAND | wx.ALIGN_RIGHT, 0)

        spin.bind_change_event(self.on_change)

        return box

    def on_change(self, e):
        event_object = e.GetEventObject()
        event_object.update_object_characteristic()
        self.set_saved_state(False)
