from wx import wx

from pkg.settings.lines_settings import LINES_DATA


class UpdateObjectCharacteristicMixin:
    def update_object_characteristic(self):
        value = self.GetValue()

        if len(str(value)) > self.max_length:
            message = "Your value is too long, max length : " + str(self.max_length) + ' ; your length : ' + str(
                len(str(value))) + ' -> ' + str(value) + "\nYou must provide a shorter value"
            dlg = wx.MessageDialog(self, message, 'Warning !', wx.OK | wx.ICON_WARNING)
            dlg.ShowModal()
            dlg.Destroy()
            self.SetValue(self.object.__getattribute__(self.attribute_name))
            # raise Exception(message)
        else:
            self.object.update_characteristic(self.attribute_name, value)

    def get_max_length(self, attribute_name):

        characteristic = next(characteristic for characteristic in LINES_DATA[self.object.key] if
                              characteristic['attribute_name'] == attribute_name)

        start_column = characteristic['start_column']
        end_column = characteristic['end_column']
        required_len = end_column - start_column + 1

        return required_len
