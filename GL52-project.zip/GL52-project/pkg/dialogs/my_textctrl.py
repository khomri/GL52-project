from wx import TextCtrl, EVT_TEXT

from mixins import UpdateObjectCharacteristicMixin


class MyTextCtrl(TextCtrl, UpdateObjectCharacteristicMixin):
    def __init__(self, parent, object, attribute_name, *args, **kwargs):
        super(MyTextCtrl, self).__init__(parent, *args, **kwargs)

        self.object = object
        self.attribute_name = attribute_name
        self.max_length = self.get_max_length(attribute_name)

    def bind_change_event(self, method):
        self.Bind(EVT_TEXT, method)
