from wx import SpinCtrlDouble, EVT_SPINCTRLDOUBLE

from mixins import UpdateObjectCharacteristicMixin


class MySpinCtrlDouble(SpinCtrlDouble, UpdateObjectCharacteristicMixin):
    def __init__(self, parent, object, attribute_name, *args, **kwargs):
        super(MySpinCtrlDouble, self).__init__(parent, max=100000000, *args, **kwargs)

        self.object = object
        self.attribute_name = attribute_name
        self.max_length = self.get_max_length(attribute_name)

    def bind_change_event(self, method):
        self.Bind(EVT_SPINCTRLDOUBLE, method)
