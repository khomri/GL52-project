from random import randint

from wx import wx
from wx.lib.floatcanvas import FloatCanvas as FC
from wx.lib.floatcanvas import FloatCanvas, Resources
from wx.lib.floatcanvas import GUIMode
from wx.lib.floatcanvas.NavCanvas import NavCanvas

from pkg.components.bus import Bus
from pkg.components.charge import Charge
from pkg.components.source import Source
from pkg.components.storage import Storage
from pkg.dialogs.dialogs import MyAskDialog
from pkg.links.branch import Branch
from pkg.links.line import Line
from pkg.microgrid_parser.microgrid_parser import MicroGridParser
from pkg.settings.file_settings import OBJECT_NAMES
from pkg.settings.lines_settings import LINES_DATA


class Modes:
    (
        POINTER,
        ZOOM_IN,
        ZOOM_OUT,
        PAN,
        BUS,
        SOURCE,
        CHARGE,
        STORAGE,
        LINE,
        BRANCH
    ) = range(10)

    def get_modes(self):
        return {
            self.POINTER: ("Pointer", "Drag a component to move it", GUIMode.GUIMouse(), Resources.getPointerBitmap()),
            self.ZOOM_IN: ("Zoom In", "Click somewhere to zoom in", GUIMode.GUIZoomIn(), Resources.getMagPlusBitmap()),
            self.ZOOM_OUT: ("Zoom Out", "Click somewhere to zoom out", GUIMode.GUIZoomOut(), Resources.getMagMinusBitmap()),
            self.PAN: ("Pan", "Drag on the canvas to move it", GUIMode.GUIMove(), Resources.getHandBitmap()),
            self.BUS: ("Bus (Ctrl+B)", "Click somewhere to insert a bus", GUIMode.GUIMouse(), wx.Bitmap('resources/' + Bus.key + '_small.png', wx.BITMAP_TYPE_PNG)),
            self.SOURCE: ("Source (Ctrl+G)", "Click somewhere to insert a source", GUIMode.GUIMouse(), wx.Bitmap('resources/' + Source.key + '_small.png', wx.BITMAP_TYPE_PNG)),
            self.CHARGE: ("Charge (Ctrl+A)", "Click somewhere to insert a source", GUIMode.GUIMouse(), wx.Bitmap('resources/' + Charge.key + '_small.png', wx.BITMAP_TYPE_PNG)),
            self.STORAGE: ("Storage (Ctrl+T)", "Click somewhere to insert a storage", GUIMode.GUIMouse(), wx.Bitmap('resources/' + Storage.key + '_small.png', wx.BITMAP_TYPE_PNG)),
            self.LINE: ("Line (Ctrl+L)", "Connecting bus", GUIMode.GUIMouse(), wx.Bitmap('resources/' + Line.key + '_small.png', wx.BITMAP_TYPE_PNG)),
            self.BRANCH: ("Branch (Ctrl+R)", "Connecting components to bus", GUIMode.GUIMouse(), wx.Bitmap('resources/' + Branch.key + '_small.png', wx.BITMAP_TYPE_PNG)),
        }


class MyCanvas(NavCanvas, Modes):
    DELETE_MENU = "Delete"
    DETAILS_MENU = "Details"

    DELETABLE_CLASSES = (Bus, Line, Source, Storage, Branch, Charge)
    EDITABLE_CLASSES = (Bus, Line)
    ADDING_COMPONENTS_MODES = (Modes.BUS, Modes.SOURCE, Modes.STORAGE, Modes.CHARGE)

    def __init__(self,
                 parent,
                 id=wx.ID_ANY,
                 size=wx.DefaultSize,
                 **kwargs):  # The rest just get passed into FloatCanvas

        self.Modes = self.get_modes()
        wx.Panel.__init__(self, parent, id, size=size)

        self.Bind(FC.EVT_MOTION, self.on_move)
        self.Bind(FC.EVT_LEFT_UP, self.on_left_up)

        self.frame = parent
        self.components = {object_name: {} for object_name in OBJECT_NAMES.values()}

        self.BuildToolbar()

        ## Create the vertical sizer for the toolbar and Panel
        box = wx.BoxSizer(wx.VERTICAL)
        box.Add(self.ToolBar, 0, wx.ALL | wx.ALIGN_LEFT | wx.GROW, 4)

        self.Canvas = FloatCanvas.FloatCanvas(self, **kwargs)
        self.Canvas.ZoomToBB()

        box.Add(self.Canvas, 1, wx.GROW)

        self.SetSizerAndFit(box)

        # default to first mode
        self.Canvas.SetMode(self.ModesDict[Modes.POINTER])

    def BuildToolbar(self):
        """
        This is here so it can be over-ridden in a ssubclass, to add extra tools, etc
        """
        tb = wx.ToolBar(self)
        self.ToolBar = tb
        tb.SetToolBitmapSize((24, 24))
        self.AddToolbarModeButtons(tb, self.Modes)
        self.AddToolbarZoomButton(tb)

        tb.AddSeparator()
        self.display_button = wx.Button(tb, label="Display bus names")
        tb.AddControl(self.display_button)
        self.display_button.Bind(wx.EVT_BUTTON, self.display_bus_names)

        tb.Realize()
        ## fixme: remove this when the bug is fixed!
        # wx.CallAfter(self.HideShowHack) # this required on wxPython 2.8.3 on OS-X

    def display_bus_names(self, event):
        labels = {
            False: "Display bus names",
            True: "Hide bus names",
        }

        Bus.display_names = not Bus.display_names
        self.display_button.SetLabel(labels[Bus.display_names])

        for bus in self.components[Bus.key].values():
            bus.set_text()

        self.Canvas.Draw(True)

    def reset(self):
        self.SetMode(Modes.POINTER)
        self.moving = False
        self.move_object = None
        self.object_buffer = None

        self.Canvas.ClearAll()
        self.Canvas.Draw(True)

        self.components = {object_name: {} for object_name in OBJECT_NAMES.values()}

    def AddToolbarModeButtons(self, tb, Modes):
        self.ModesDict = {}
        for n, Mode in Modes.items():
            tool = tb.AddRadioTool(n, shortHelp=Mode[0], bitmap=Mode[3])
            self.Bind(wx.EVT_TOOL, self.SetMode, tool)
            self.ModesDict[tool.GetId()] = Mode[2]

    def SetMode(self, event):
        if isinstance(event, int):
            id = event
        else:
            id = event.GetId()

        Mode = self.ModesDict[id]
        self.frame.SetStatusText(self.Modes[id][1])
        self.Canvas.SetMode(Mode)
        self.ToolBar.ToggleTool(id, True)
        self.mode = id
        self.object_buffer = None

        if self.mode is Modes.LINE:
            self.frame.SetStatusText(self.Modes[id][1] + ", click on bus #1")
        elif self.mode is Modes.BRANCH:
            self.frame.SetStatusText(self.Modes[id][1] + ", click on bus")

    def add_bus_from_formatted(self, formatted_characteristics):
        id_characteristic = next(characteristic for characteristic in LINES_DATA[Bus.key] if
                                 characteristic['attribute_name'] == 'id')
        id = MicroGridParser.read_characteristic(id_characteristic, formatted_characteristics)
        self.add_component(id, Bus, formatted_characteristics=formatted_characteristics)

    def add_line_from_formatted(self, formatted_characteristics):
        from_characteristic = next(characteristic for characteristic in LINES_DATA[Line.key] if
                                   characteristic['attribute_name'] == 'from_object_id')
        to_characteristic = next(characteristic for characteristic in LINES_DATA[Line.key] if
                                 characteristic['attribute_name'] == 'to_object_id')
        from_id = MicroGridParser.read_characteristic(from_characteristic, formatted_characteristics)
        to_id = MicroGridParser.read_characteristic(to_characteristic, formatted_characteristics)
        object1 = self.get_object(from_id, Bus.key)
        object2 = self.get_object(to_id, Bus.key)

        self.connect(object1, object2, Line, formatted_characteristics=formatted_characteristics)

    def add_bus_from_json(self, json_characteristics):
        self.add_component_from_json(Bus.key, Bus, json_characteristics)

    def add_source_from_json(self, json_characteristics):
        self.add_component_from_json(Source.key, Source, json_characteristics)

    def add_storage_from_json(self, json_characteristics):
        self.add_component_from_json(Storage.key, Storage, json_characteristics)

    def add_charge_from_json(self, json_characteristics):
        self.add_component_from_json(Charge.key, Charge, json_characteristics)

    def add_component_from_json(self, component_key, component_class, json_characteristics):
        id = json_characteristics.get('id', self.get_available_id(component_key))
        position = json_characteristics.get('XY', self.get_random_position())

        if not isinstance(position, tuple):
            position = tuple(position)

        self.add_component(id, component_class, _coords=position, json_characteristics=json_characteristics)

    def add_line_from_json(self, json_characteristics):
        self.add_link_from_json(Line, json_characteristics)

    def add_branch_from_json(self, json_characteristics):
        self.add_link_from_json(Branch, json_characteristics)

    def add_link_from_json(self, link_class, json_characteristics):
        from_id = json_characteristics.get('from_object_id')
        from_key = json_characteristics.get('from_object_key')
        to_id = json_characteristics.get('to_object_id')
        to_key = json_characteristics.get('to_object_key')

        object1 = self.get_object(from_id, from_key)
        object2 = self.get_object(to_id, to_key)

        self.connect(object1, object2, link_class, json_characteristics=json_characteristics)

    def object_hit(self, object):
        if self.mode is Modes.POINTER:
            self.moving = True
            self.StartPoint = object.HitCoordsPixel
            self.StartObject = self.Canvas.WorldToPixel(object.GetOutlinePoints())
            self.move_object = None
            self.MovingObject = object

        elif self.mode is Modes.LINE and isinstance(object, Bus):
            if self.object_buffer is None:
                self.object_buffer = object
                self.frame.SetStatusText(self.Modes[Modes.LINE][1] + ", click on bus #2")
            elif object != self.object_buffer:
                self.connect(self.object_buffer, object, Line)
                self.Canvas.Draw(True)
                self.object_buffer = None
                self.frame.SetStatusText(self.Modes[Modes.LINE][1] + ", click on bus #1")

        elif self.mode is Modes.BRANCH:
            if self.object_buffer is None and isinstance(object, Bus):
                self.object_buffer = object
                self.frame.SetStatusText(self.Modes[Modes.BRANCH][1] + ", click on component")
            elif not isinstance(object, Bus) and object != self.object_buffer:
                self.connect(self.object_buffer, object, Branch)
                self.Canvas.Draw(True)
                self.object_buffer = None
                self.frame.SetStatusText(self.Modes[Modes.BRANCH][1] + ", click on bus")

    def on_right_up(self, object):
        self.build_right_click_menus(object)
        self.PopupMenu(self.menu, object.HitCoordsPixel)
        self.menu.Destroy()

    def on_move(self, event):
        """
        Updates the status bar with the world coordinates
        and moves the object it is clicked on
        """

        if self.moving:
            dxy = event.GetPosition() - self.StartPoint
            # Draw the Moving Object:
            dc = wx.ClientDC(self.Canvas)
            dc.SetPen(wx.Pen('WHITE', 2, wx.SHORT_DASH))
            dc.SetBrush(wx.TRANSPARENT_BRUSH)
            dc.SetLogicalFunction(wx.XOR)
            if self.move_object is not None:
                dc.DrawPolygon(self.move_object)
            self.move_object = self.StartObject + dxy
            dc.DrawPolygon(self.move_object)

    def on_left_up(self, event):
        if self.moving:
            self.moving = False
            if self.move_object is not None:
                dxy = event.GetPosition() - self.StartPoint
                dxy = self.Canvas.ScalePixelToWorld(dxy)
                self.MovingObject.Move(dxy)
                self.MoveTri = None
            self.Canvas.Draw(True)

            self.set_saved_state(False)
        elif self.mode in self.ADDING_COMPONENTS_MODES:
            component_key, component_class = self.get_key_and_class_corresponding_to_mode(self.mode)
            self.add_component(self.get_available_id(component_key), component_class, _coords=tuple(event.Coords))

    def add_component(self, id, component_class, _coords=None, formatted_characteristics=None,
                      json_characteristics=None):

        if _coords is None:
            coords = self.get_random_position()
        else:
            coords = _coords

        category = component_class.key

        component = component_class(id=id,
                                    canvas=self.Canvas,
                                    coords=coords,
                                    formatted_characteristics=formatted_characteristics,
                                    json_characteristics=json_characteristics)

        self.components[category][id] = component
        self.Canvas.AddObject(component)

        component.Bind(FC.EVT_FC_LEFT_DOWN, self.object_hit)
        component.Bind(FC.EVT_FC_RIGHT_UP, self.on_right_up)

        self.Canvas.Draw(True)
        self.Canvas.ZoomToBB()

        self.set_saved_state(False)

        return component

    def get_available_id(self, category):
        id = None

        existing_ids = self.components[category].keys()
        potential_id = 1
        while id is None:
            if potential_id not in existing_ids:
                id = potential_id
            else:
                potential_id += 1
        return id

    def get_key_and_class_corresponding_to_mode(self, mode):

        component_key = component_class = None

        if mode == Modes.BUS:
            component_key, component_class = Bus.key, Bus
        elif mode == Modes.SOURCE:
            component_key, component_class = Source.key, Source
        elif mode == Modes.STORAGE:
            component_key, component_class = Storage.key, Storage
        elif mode == Modes.CHARGE:
            component_key, component_class = Charge.key, Charge

        return component_key, component_class

    def get_object(self, id, type):
        return self.components.get(type, {}).get(id)

    def remove_object(self, object):
        category = object.key
        id = object.get_id()
        if id in self.components.get(category, {}): del self.components[category][id]

        object.remove()
        self.set_saved_state(False)
        self.Canvas.Draw(True)

    def connect(self, object1, object2, link_class, formatted_characteristics=None, json_characteristics=None):
        link = None

        if object1 is not None and object2 is not None and object1 != object2:
            link = link_class(object1=object1,
                              object2=object2,
                              canvas=self.Canvas,
                              formatted_characteristics=formatted_characteristics,
                              json_characteristics=json_characteristics)

            link_id = link.get_id()

            if link_id not in self.components.get(link_class.key, {}):
                self.Canvas.AddObject(link)

                link.Bind(FC.EVT_FC_RIGHT_UP, self.on_right_up)

                self.components[link_class.key][link_id] = link
                self.set_saved_state(False)

        return link

    def get_random_position(self):
        return randint(0, 9), randint(0, 9)

    def build_right_click_menus(self, object):

        menu_titles = []

        if isinstance(object, self.EDITABLE_CLASSES):
            menu_titles.append(self.DETAILS_MENU)

        if isinstance(object, self.DELETABLE_CLASSES):
            menu_titles.append(self.DELETE_MENU)

        self.menu = wx.Menu()
        self.right_click_menus = {}
        for title in menu_titles:
            id = wx.NewId()
            self.menu.Append(id, title)
            self.right_click_menus[id] = title
            wx.EVT_MENU(self.menu, id, lambda event, object=object: self.menu_selection(event, object))

    def menu_selection(self, event, object):
        selected_menu = self.right_click_menus.get(event.GetId())
        if selected_menu == self.DELETE_MENU:
            self.remove_object(object)
        elif selected_menu == self.DETAILS_MENU:
            dlg = MyAskDialog(object, self.set_saved_state)
            dlg.ShowModal()
        else:
            raise Exception('Unsupported menu event : ' + selected_menu)

    def set_saved_state(self, bool):
        self.frame.set_saved_state(bool)
