from pkg.adaptators.branch_connectable_component_adaptator import BranchConnectableComponentAdaptator

from pkg.settings.file_settings import OBJECT_NAMES


class Storage(BranchConnectableComponentAdaptator):
    key = OBJECT_NAMES.get('STORAGE_NAME', '')

    def __init__(self, *args, **kwargs):
        super(Storage, self).__init__(*args, **kwargs)
