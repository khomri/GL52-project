import wx
from wx.lib.floatcanvas import FloatCanvas as FC

from pkg.components.mixins import MovingMixin, ConnectorMixin
from ..mixins.mixins import CharacteristicsMixin


class BaseComponent(FC.ScaledBitmap, MovingMixin, ConnectorMixin, CharacteristicsMixin):
    def __init__(self, id, canvas, coords, formatted_characteristics=None, json_characteristics=None, *args,
                 **kwargs):
        super(BaseComponent, self).__init__(
            wx.Image('resources/' + self.key + '.png'),
            coords,
            InForeground=True,
            Height=1,
            Position='cc',
            *args,
            **kwargs
        )

        self.canvas = canvas
        self.set_characteristics(formatted_characteristics=formatted_characteristics,
                                 json_characteristics=json_characteristics)

        self.id = id

    def get_id(self):
        return self.id

    def remove(self):
        self.canvas.RemoveObject(self)

    def __str__(self):
        return self.get_formatted_characteristics()
