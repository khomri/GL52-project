class BranchConnectable(object):
    def __init__(self, *args, **kwargs):
        self.branches = []

    def add_branch(self, branch):
        self.branches.append(branch)

    def get_branches(self):
        return self.branches

    def remove(self):
        for branch in self.get_branches():
            branch.remove()
