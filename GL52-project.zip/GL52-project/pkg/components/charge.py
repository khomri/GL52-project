from pkg.adaptators.branch_connectable_component_adaptator import BranchConnectableComponentAdaptator

from pkg.settings.file_settings import OBJECT_NAMES


class Charge(BranchConnectableComponentAdaptator):
    key = OBJECT_NAMES.get('CHARGE_NAME', '')

    def __init__(self, *args, **kwargs):
        super(Charge, self).__init__(*args, **kwargs)
