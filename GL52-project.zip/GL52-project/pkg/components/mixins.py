import numpy as N


class MovingMixin:
    """
    Methods required for a Moving object

    """

    def GetOutlinePoints(self):
        BB = self.BoundingBox
        OutlinePoints = N.array(((BB[0, 0], BB[0, 1]),
                                 (BB[0, 0], BB[1, 1]),
                                 (BB[1, 0], BB[1, 1]),
                                 (BB[1, 0], BB[0, 1]),
                                 )
                                )

        return OutlinePoints


class ConnectorMixin:
    """
    Mixin class for DrawObjects that can be connected with links

    NOte that this versionony works for Objects that have an "XY" attribute:
      that is, one that is derived from XHObjectMixin.

    """

    def GetConnectPoint(self):
        return self.XY
