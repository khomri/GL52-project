from pkg.adaptators.branch_connectable_component_adaptator import BranchConnectableComponentAdaptator

from pkg.settings.file_settings import OBJECT_NAMES


class Source(BranchConnectableComponentAdaptator):
    key = OBJECT_NAMES.get('SOURCE_NAME', '')

    def __init__(self, *args, **kwargs):
        super(Source, self).__init__(*args, **kwargs)
