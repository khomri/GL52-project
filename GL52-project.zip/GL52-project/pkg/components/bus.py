import numpy as N
import wx
from wx.lib.floatcanvas.FloatCanvas import ScaledText

from pkg.adaptators.branch_connectable_component_adaptator import BranchConnectableComponentAdaptator
from pkg.adaptators.line_connectable_component_adaptator import LineConnectableComponentAdaptator
from pkg.settings.file_settings import OBJECT_NAMES


class Bus(BranchConnectableComponentAdaptator, LineConnectableComponentAdaptator):
    display_names = False
    key = OBJECT_NAMES.get('BUS_NAME', '')

    def __init__(self, *args, **kwargs):

        super(Bus, self).__init__(*args, **kwargs)

        self.set_text()

    def set_text(self):

        string = str(self.get_id())
        if hasattr(self, 'name') and self.display_names and self.name:
            string += ' - ' + self.name

        try:
            self.canvas.RemoveObject(self.text)
        except Exception:
            pass

        self.text = ScaledText(string,
                               N.add(self.XY, (0, -0.25)),
                               0.25,
                               Color="Black",
                               Family=wx.ROMAN,
                               Style=wx.NORMAL,
                               Weight=wx.NORMAL,
                               Underlined=False,
                               Position='tc',
                               InForeground=True)

        self.canvas.AddObject(self.text)

    def Move(self, dxy):
        super(Bus, self).Move(dxy)
        self.text.Move(dxy)

    def remove(self):
        self.canvas.RemoveObject(self.text)
        super(Bus, self).remove()

    def update_characteristic(self, attribute_name, attribute_value):
        super(Bus, self).update_characteristic(attribute_name, attribute_value)

        if attribute_name == 'name' and self.display_names:
            self.set_text()
            self.canvas.Draw(True)
