class LineConnectable(object):
    def __init__(self, *args, **kwargs):
        self.lines = []

    def add_line(self, line):
        self.lines.append(line)

    def get_lines(self):
        return self.lines

    def remove(self):
        for line in self.get_lines():
            line.remove()
