#!/usr/bin/env python

import os
import sys
from os.path import isfile
from pydoc import locate
from string import strip

from pkg.settings.file_settings import FILE_DATA
from pkg.settings.lines_settings import LINES_DATA


class MicroGridParser():
    def __init__(self):
        pass

    @staticmethod
    def print_characteristic(data, title):
        """
        Prints a characteristic title and value (basically used to see if the microgrid_parser is working correctly).

        :param data: the value of
        :param title:
        :return:
        """
        # print("'" + title + "' : ", end="")
        sys.stdout.write("'" + title + "' : ")
        # print "'"
        # print data, end="")
        sys.stdout.write("'" + str(data))
        print("'")

    @staticmethod
    def read_characteristic(characteristic, line):
        """
        Reads the characteristic value for each characteristic of a line.

        :param characteristic: the characteristic data, contains information such as the starting and ending column,
        a title...
        :param line: the line where the characteristic value will be read
        """

        title = characteristic['title']
        start_column = characteristic['start_column']
        end_column = characteristic['end_column']
        attribute_type = characteristic.get('attribute_type')
        value = ''

        # New version to read links. Allowed to detect a mistake in the description file at line 128 and 129 :
        # Original :
        #     Columns 113-119 Minimum voltage, MVAR or MW limit (F)
        #     Columns 120-126 Maximum voltage, MVAR or MW limit (F)
        # Should be (according to provided exemples) :
        #     Columns 113-118 Minimum voltage, MVAR or MW limit (F)
        #     Columns 119-121 Maximum voltage, MVAR or MW limit (F)
        for n in range(start_column - 1, end_column):
            try:
                value += line[n]
            except IndexError as e:
                raise IndexError("lines_settings.py file must be badly filled (wrong columns indexes) - " + str(e))

        if attribute_type is not None:
            type = locate(attribute_type)

            try:
                value = type(value)
                if type is str:
                    value = strip(value)
            except ValueError as e:
                raise ValueError(
                    "Error at characteristic " + title + ", start column " + str(start_column) + ", end column " + str(
                        end_column) + " - " + str(e))

        # Old version to read links. Read each character instead of only the needed ones.
        # for n, character in enumerate(line):
        #     if (n >= d['start_column']-1 and n <= d['end_column']-1):
        #         value += character

        MicroGridParser.print_characteristic(value, title)

        return value

    @staticmethod
    def read_split_files():
        """
        Reads the split temporary files and each characteristic title and value for every line.
        """

        print("Reading splitted files\n")

        for section_name, section in FILE_DATA.items():
            print("\nReading section : " + section_name + "\n")

            with open(section['temporary_output_file']) as f:
                f.readline()  # Skips the first line as it is the section start card
                for n, line in enumerate(f):
                    print("\nLine #" + str(n + 1) + "\n")

                    for characteristic in LINES_DATA.get(section_name):
                        MicroGridParser.read_characteristic(characteristic, line)

                    print("\nEnd of line #" + str(n + 1) + "\n")

            print("\nEnd of section : " + section_name + "\n")

    @staticmethod
    def get_temporary_output_file(line, split_file, current_section):
        """
        Returns a tuple like (res_split_file, res_current_section) where res_split_file
        is the file to write the line and res_current_section is the name of the associated section
        (e.g. : "bus", "links").
        This method is called while looping on the links of the description file.
        When a line matches a "section start pattern" (defined in file_settings.py), the method
        returns the associated temporary output file (i.e. : the 'temporary_output_file' value in file_settings.py).
        When iterating over links of a section (i.e. : bus, links), the method returns the file and
        section name unchanged.
        When a line matches a "section end pattern" the method closes the file and returns an empty file and
        section name, to inform the next iteration that the old section is finished and that a new one may start.

        :param line: the current line
        :param split_file: the current file to write the line (may be null)
        :param current_section: the current section name
        :return: a tuple like (res_split_file, res_current_section)
        """

        res_split_file = split_file
        res_current_section = current_section

        if split_file is None:
            for section_name, data_constant in FILE_DATA.items():
                if data_constant['start'] in line:
                    print("Section start : " + section_name)
                    res_split_file = open(data_constant['temporary_output_file'], 'w')
                    res_current_section = section_name

        else:
            if FILE_DATA[current_section]['end'] in line:
                split_file.close()
                print("Section end : " + current_section + " => " + str(
                    sum(1 for line in open(FILE_DATA[current_section]['temporary_output_file'])) - 1) + " links")
                res_split_file = None
                res_current_section = ""

        return res_split_file, res_current_section

    @staticmethod
    def write_line_in_temporary_output_file(line, split_file):
        """
        Writes the given line in the given file if it is not null (i.e. : if the
        read line belongs to a desired section)

        :param line: the line to write
        :param split_file: the file to write the line to if not null
        """

        if split_file is not None:
            split_file.write(line)

    @staticmethod
    def remove_temporary_files():
        """
        Removes the temporary files.
        """

        for section in FILE_DATA.values():
            path = section['temporary_output_file']
            if isfile(path):
                os.remove(path)

    @staticmethod
    def parse_file(path):
        """
        Splits the initial file into specific temporary files for each section.
        """

        print("Splitting initial file into specific temporary files per section\n")

        split_file = None
        current_section = ""

        with open(path) as f:
            for n, line in enumerate(f):
                split_file, current_section = MicroGridParser.get_temporary_output_file(line, split_file,
                                                                                        current_section)
                MicroGridParser.write_line_in_temporary_output_file(line, split_file)
