from pkg.links.base_link import BaseLink
from pkg.settings.file_settings import OBJECT_NAMES


class Line(BaseLink):
    key = OBJECT_NAMES.get('LINE_NAME', '')

    def __init__(self, *args, **kwargs):
        super(Line, self).__init__(*args, **kwargs)
