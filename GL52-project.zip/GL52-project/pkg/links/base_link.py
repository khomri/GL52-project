import numpy as N
from wx.lib.floatcanvas import FloatCanvas as FC
from wx.lib.floatcanvas.Utilities import BBox

from pkg.mixins.mixins import CharacteristicsMixin


class BaseLink(FC.LineOnlyMixin, FC.DrawObject, CharacteristicsMixin):
    specific_json_characteristics = [
        'from_object_id',
        'from_object_key',
        'to_object_id',
        'to_object_key'
    ]

    def __init__(self, object1, object2, canvas, formatted_characteristics=None, json_characteristics=None,
                 LineColor="Black",
                 LineStyle="Solid", LineWidth=1):

        FC.DrawObject.__init__(self, InForeground=False)

        self.canvas = canvas

        self.from_object = object1
        self.to_object = object2

        self.from_object.add_branch(self)
        self.to_object.add_branch(self)

        self.CalcBoundingBox()
        self.SetPen(LineColor, LineStyle, LineWidth)

        self.HitLineWidth = max(LineWidth, self.MinHitLineWidth)

        self.set_characteristics(formatted_characteristics=formatted_characteristics,
                                 json_characteristics=json_characteristics)

        self.from_object_id = self.from_object.get_id()
        self.from_object_key = self.from_object.key
        self.to_object_id = self.to_object.get_id()
        self.to_object_key = self.to_object.key

    def CalcBoundingBox(self):
        self.BoundingBox = BBox.fromPoints((self.from_object.GetConnectPoint(),
                                            self.to_object.GetConnectPoint()))
        if self._Canvas:
            self._Canvas.BoundingBoxDirty = True

    def _Draw(self, dc, WorldToPixel, ScaleWorldToPixel, HTdc=None):
        Points = N.array((self.from_object.GetConnectPoint(),
                          self.to_object.GetConnectPoint()))
        Points = WorldToPixel(Points)
        dc.SetPen(self.Pen)
        dc.DrawLines(Points)
        if HTdc and self.HitAble:
            HTdc.SetPen(self.HitPen)
            HTdc.DrawLines(Points)

    def get_id(self):
        return str(self.to_object_key + '_' + str(self.from_object_id) + '-' + self.to_object_key + '_' + str(
            self.to_object_id))

    def remove(self):
        # Mandatory to catch a weird exception raised in some undetermined cases
        try:
            self.canvas.RemoveObject(self)
        except ValueError:
            pass

    def get_json_characteristics(self):
        json_characteristics = super(BaseLink, self).get_json_characteristics()

        for characteristic in self.specific_json_characteristics:
            if hasattr(self, characteristic):
                value = self.__getattribute__(characteristic)
                json_characteristics[characteristic] = value

        return json_characteristics

    def __str__(self):
        return self.get_formatted_characteristics()
