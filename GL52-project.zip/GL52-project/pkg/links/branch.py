from pkg.links.base_link import BaseLink
from pkg.settings.file_settings import OBJECT_NAMES


class Branch(BaseLink):
    key = OBJECT_NAMES.get('BRANCH_NAME', '')

    def __init__(self, *args, **kwargs):
        super(Branch, self).__init__(LineStyle="ShortDash", *args, **kwargs)
