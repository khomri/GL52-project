from pkg.components.base_component import BaseComponent
from pkg.components.branch_connectable import BranchConnectable


class BranchConnectableComponentAdaptator(BaseComponent):
    def __init__(self, *args, **kwargs):
        self.branchConnectable = BranchConnectable()
        super(BranchConnectableComponentAdaptator, self).__init__(*args, **kwargs)

    def add_branch(self, branch):
        self.branchConnectable.add_branch(branch)

    def get_branches(self):
        return self.branchConnectable.get_branches()

    def remove(self):
        self.branchConnectable.remove()
        super(BranchConnectableComponentAdaptator, self).remove()
