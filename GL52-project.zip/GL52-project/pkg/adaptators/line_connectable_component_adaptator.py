from pkg.components.base_component import BaseComponent
from pkg.components.line_connectable import LineConnectable


class LineConnectableComponentAdaptator(BaseComponent):
    def __init__(self, *args, **kwargs):
        self.lineConnectable = LineConnectable()
        super(LineConnectableComponentAdaptator, self).__init__(*args, **kwargs)

    def add_line(self, line):
        self.lineConnectable.add_line(line)

    def get_lines(self):
        return self.lineConnectable.get_lines()

    def remove(self):
        self.lineConnectable.remove()
        super(LineConnectableComponentAdaptator, self).remove()
